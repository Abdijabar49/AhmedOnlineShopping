<?php
session_start();
if(isset($_SESSION["uid"])){
	header("location:profile.php");
}
include("header.php");
include("dbconnection.php");
$dt = date("Y-m-d h:i:s");
$logres=null;
						if(isset($_POST["login"]))
						{
						$result = mysqli_query($con,"SELECT * FROM users where username='$_POST[username]' AND password='$_POST[password]'");

					if(mysqli_num_rows($result) == 1)
					{
							   $sqlupd = "UPDATE users SET lastlogin='$dt' where username='$_POST[username]'";
								mysqli_query($con,$sqlupd);
							
							while($row = mysqli_fetch_array($result))
							{
								$_SESSION["userid"] =  $row["userID"];
								$_SESSION['username'] = $row["username"];
								$_SESSION['fname'] = $row["firstName"];
								$_SESSION['lname'] = $row["lastName"];
								$_SESSION['type'] = $row["userType"];
								$_SESSION['lastlogin'] = $row["lastlogin"];
							}
						?>
										 <script>
						
						 window.location="admin/index.php";
						 </script> 
							   
							<?php
					}
					else
					{
						$logres = "Invalid User name and password entered..";
					}


					}
					?>
	<!-- Cart -->

	<div class="cart_section">
		<div class="container">
			<div class="row">
				<div class="col-lg-10 offset-lg-1">
					<div class="cart_container">
					<div class="cart_title">Login</div>
						<div class="cart_items">
							<font color="#FF0000"><b><?php  echo $logres; ?></b></font>
						<form action="" method="post" name="form1" onsubmit="return validation();">
							<input type="hidden" name="next" value="/">
							<fieldset>
								<div class="field-long">
									<label class="control-label">Username</label>
									<div class="controls">
										<input type="text" placeholder="Enter your username" id="username" name="username" class="contact_form_phone input_field" require>
									</div>
								</div>
								<div class="control-group">
									<label class="control-label">Password</label>
									<div class="controls">
										<input type="password" placeholder="Enter your password" id="password" name="password" class="contact_form_phone input_field" require>
									</div>
								</div><br>
								<div class="control-group">
								<input  type="submit" name="login" value="Log In"  class="button contact_submit_button" >
									
									<hr>
									<p class="reset">Recover your <a tabindex="4" href="#" title="Recover your username or password">username or password</a></p>
								</div>
							</fieldset>
						</form>	
			
				
					</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<?php
	include("footer.php");
	?>