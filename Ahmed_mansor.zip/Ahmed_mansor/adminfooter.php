  <!---- Menu Ares Ends  -------->
		 
		 
		    <div class="row header">

        <section id="copyright">
				<center><span style="font-size:18px">Copyright &copy; 2018  Alaabo.com All right reserved.</span><center>
			</section>
		
           
        </div>
        <script src="js/bootstrap.min.js"></script>
    </body>
</html>