
<!-- Footer -->

	<footer class="footer">
		<div class="container">
			<div class="row">

				<div class="col-lg-3 footer_col">
					
				</div>

			

			</div>
		</div>
	</footer>

	<!-- Copyright -->
									<div class="custom_dropdown_placeholder clc"></div>
											
												<div class="custom_list clc"></div>
	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col">
					
					<div class="copyright_container d-flex flex-sm-row flex-column align-items-center justify-content-start">
						<div class="copyright_content"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved |<a href="https://colorlib.com" target="_blank"></a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</div>
						<div class="logos ml-sm-auto">
							<ul class="logos_list">
								<li><img src="images/edahab.png" alt="" width="50" height="40"></li>
								<li><img src="images/evc.jpg" alt="" width="50" height="40"></li>
								<li><img src="images/zaad.jpg" alt="" width="50" height="40"></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


</body>

</html>