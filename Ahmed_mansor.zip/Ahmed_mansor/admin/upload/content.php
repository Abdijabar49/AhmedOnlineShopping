					
				
							<ul class="thumbnails listing-products">
							
							<div class="col-md-12 col-xs-12" >
					</div>
					
							<?php
							
							
		
			
				// qaybta display products //				
			$limit = 2;  
						if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };  
						$start_from = ($page-1) * $limit; 
	
	
			//$sql_query = "SELECT product_name, product_desc, id, product_image, product_price FROM shop_products";


					$sql_query = "SELECT name, id, image1, price FROM product";	
		    $resultset = mysqli_query($con, $sql_query) or die("database error:". mysqli_error($con));
			while( $row = mysqli_fetch_assoc($resultset) ) {
			/*$sql = "SELECT name, price, id, image1 FROM product";  
						$rs_result = mysqli_query($con, $sql); 
						while ($data = mysqli_fetch_assoc($rs_result)) {*/
								$pro_id = $row['id'];
								$pro_name = $row['name'];
								$pro_price = $row['price'];
								$pro_image = $row['image1']; 
			?>
			<form class="product-form">
			<div class='grid_1_of_4 images_1_of_4'>
						<div class="agile-products">
							<div class='new-tag'><h6>New </h6></div>
							<a href="product-detail.php?id=<?php echo $row["image1"]; ?> ">
						<?php
							if($pro_image == 0)
							{
							?>
						<img src="images/noimage.jpg"  style="ax-height: 231px;min-height: 231px;" class="img-responsive" alt="img" />
							<?php
							}
							else
							{
								?>
							
							<img src="images/product/thumb/<?php echo $row["image1"]; ?>"  style="max-height: 231px;min-height: 231px;" class="img-responsive" alt="img"></a>
						
							<?php
							}
							?>
								 <div class="truncate"><a href="product-detail.php?id=<?php echo $row["id"]; ?>"><?php echo $row["name"]; ?></a></div>
								
								<h6><del></del>$<?php echo $row["price"]; ?></h6>
								
						<input name="product_code" type="text" value="<?php echo $row['id']; ?>">
							 <input type="hidden" name="product_qty"  style="max-width:50px;" value="1" >
							 
							<button type="submit" > Add to cart</button>
									
							
							</div>
						</div>
						</form>

			<?php						
			
		
						}
					
	?>
							
						
						
							
							</ul>
							<hr>
						<?php  
							$sql = "SELECT COUNT(id) FROM product";  
							$rs_result = mysqli_query($con, $sql);  
							$row = mysqli_fetch_row($rs_result);  
							$total_records = $row[0];  
							$total_pages = ceil($total_records / $limit);  
							$pagLink = "<nav><ul class='pagination'>";  
							for ($i=1; $i<=$total_pages; $i++) {  
										 $pagLink .= "<li><a href='index.php?page=".$i."'>".$i."</a></li>";  
							};  
							echo $pagLink . "</ul></nav>";  
					?>
						
						<script type="text/javascript">
						$(document).ready(function(){
						$('.pagination').pagination({
								items: <?php echo $total_records;?>,
								itemsOnPage: <?php echo $limit;?>,
								cssStyle: 'light-theme',
								currentPage : <?php echo $page;?>,
								hrefTextPrefix : 'index.php?page='
							});
							});
						</script>

							