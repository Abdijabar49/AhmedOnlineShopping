<?php
include("header.php");
include("menu.php");
include("dbconnection.php");

?>
<script language="javascript" type="text/javascript">
        function printDiv(divID) {
            //Get the HTML of div
            var divElements = document.getElementById(divID).innerHTML;
            //Get the HTML of whole page
            var oldPage = document.body.innerHTML;

            //Reset the page's HTML with div's HTML only
            document.body.innerHTML = 
              "<html><head><title></title></head><body>" + 
              divElements + "</body>";

            //Print Page
            window.print();

            //Restore orignal HTML
            document.body.innerHTML = oldPage;

          
        }
    </script>
   
            <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list single-page-breadcome">
                                <div class="row">
									 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <div class="breadcome-heading">
                                              
								
										 
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Product Order Detail</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="product-status mg-tb-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-status-wrap">
                           <div id="printablediv" style="width: 100%;"> 
							<h4 class="title">Customer Informaiton</h4>
							<div class="add-product">
                                <a href="product-order.php">Back</a>
                            </div>
								
	   <?php


 
 
										 $msg=null;
				   
$i=1;
	

$query= mysqli_query($con,"select * from shippingdetails where id='$_GET[prodid]'");
									$row2= mysqli_fetch_array($query);
									
									$firstname = $row2["firstname"];
								$lastname = $row2["lastname"];
								$mobile = $row2["mobile"];
								$email = $row2["email"];
								$city = $row2["city"];
								$country = $row2["country"];
								$payment_type = $row2["payment_type"];
								$total = $row2["total"];
								$address = $row2["address"];
								$shippingid = $row2["id"];
								$comments = $row2["comments"];
								$status = $row2["status"];
								
?>							
		<table>
               
				<tr>
				<td height="40" width="100"><strong>Name:</strong> </td><td> <?php echo $firstname; ?> <?php echo $lastname; ?></td>
				</tr>
				<tr>
				<td height="40"><strong>Phone:</strong> </td><td> <?php echo $mobile; ?></td>
				</tr>
				<tr>
				<td height="40"><strong>Email:</strong> </td><td> <?php echo $email; ?></td>
				</tr>
				<tr>
				<td height="40"><strong>Address:</strong> </td><td> <?php echo $address; ?></td>
				</tr>
				<tr>
				<td height="40" ><strong>City:</strong> </td><td> <?php echo $city; ?></td>
				</tr>
				<tr>
				<td height="40"><strong>Country:</strong> </td><td> <?php echo $country; ?></td>
				</tr>
				<tr>
				
				</tr>
              
        </table>
                            <table class="table table-bordered table-hover">
                <tr class="active">
                       
                        <td>Image</td>
						<td>Product</td>
                        <td>Unit Price</td>
						<td>Quantity</td>
						 <td>Total Amount</td>
                        
                </tr>
                
                     <?php
					 $msg=null;
				   
$result= mysqli_query($con,"select * from product_order where shippingid='$shippingid '");			
						
								
							while($row= mysqli_fetch_array($result))
		         { 
								
								$qty = $row["qty"];
								$amount = $row["amount"];
								$productid = $row["productid"];
								
								
								$sqlquery= mysqli_query($con,"select * from product where id='$productid'");
								$row2= mysqli_fetch_array($sqlquery);
								
						
								
					$productname= $row2['name'];	
					$unitprice= $row2['price'];
					$image= $row2['image1'];

    echo '<tr>';
	?>
	<td width="80"><img src="upload/<?php echo $image ?>" width="75" height="75" class="img1"/></td> 
   <?php echo '<td>'.$productname.'</td>'; 
   echo '<td>$ '.$unitprice.'</td>';
   echo '<td>'.$row['qty'].'</td>';
	
	echo '<td>$ '.$row['amount'].'</td>';
}

$sqlquery= mysqli_query($con,"select * from product where id='20'");
								$row2= mysqli_fetch_array($sqlquery);
							
								
?>
	
	</tr>
	<tr>
	<td colspan="3"></td>
	<td><strong>Total </strong></td>
	<td><strong> $<?php echo $total; ?></strong></td>
	</tr>
	 <tr>
		               <td height="23" colspan="2" align="center"><a href='#' onclick="javascript:printDiv('printablediv')" ><button class="btn btn-primary">Print this report</button></a></td><td></td>
	      </tr>
		</table>
		

       
                            
                      </div> 
                    </div>
                </div>
         
        </div>
    <?php
include("footer.php");
?>