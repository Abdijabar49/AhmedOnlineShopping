<?php
include("header.php");
include("menu.php");
include("dbconnection.php");
if(isset($_GET["delid"]))
{
$sqldel = "DELETE FROM shippingdetails where id='$_GET[delid]'";
$resdel = mysqli_query($con,$sqldel);
	if(!$resdel)
	{
		$msg= "<font color='red'>Failed to delete... Problem in sql query </font>";
	}
	else
	{
		$msg = "<font color='green'>Record deleted successfully..</font>";
	}
}
?>
<?php 
	$msg=null;
$dt= date("Y-m-d"); 
if(isset($_POST["insert"]))
{ 
	
			$sqlupd = "UPDATE shippingdetails SET status='$_POST[status]',comments='$_POST[comments]' WHERE id='$_POST[shippingid]'";
	$qresult = mysqli_query($con,$sqlupd);
	$ctins =  mysqli_affected_rows($con);
			if(!$qresult)
	{
		$msg = "<br><font color='green' size='4'>Failed to update record </font>";
	}
	else
	{
		$msg = "<font color='green' size='4'><br>Record updated successfully...</font>";

	}	
}
?>
   
            <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list single-page-breadcome">
                                <div class="row">
									 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <div class="breadcome-heading">
                                              
								
										 
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Product Order</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="product-status mg-tb-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-status-wrap">
                            <h4>Products Order</h4>
                           
                            <table>
                                <tr>
									<th>S/n</th>
                                    <th>Order ID</th>
                                    <th>Order Date</th>
                                    <th>Amount</th>
									<th>Order Method</th>
									<th>Status</th>
                                    <th>Setting</th>
                                </tr>
								<?php 
								$showRecordPerPage = 10;
	if(isset($_GET['page']) && !empty($_GET['page'])){
		$currentPage = $_GET['page'];
	}else{
		$currentPage = 1;
	}
	$startFrom = ($currentPage * $showRecordPerPage) - $showRecordPerPage;
	$totalEmpSQL = "SELECT * FROM shippingdetails";
	$allEmpResult = mysqli_query($con, $totalEmpSQL);
	$totalEmployee = mysqli_num_rows($allEmpResult);
	$lastPage = ceil($totalEmployee/$showRecordPerPage);
	$firstPage = 1;
	$nextPage = $currentPage + 1;
	$previousPage = $currentPage - 1;
										 $msg=null;
				  
				   
$i=1;
$sql = "SELECT * FROM shippingdetails ORDER BY id desc LIMIT $startFrom, $showRecordPerPage";   
						$st = mysqli_query($con, $sql);	
		
					  
?>
                               
								
								<?php
					 $msg=null;
				   
$i=1;
				   


while($row=mysqli_fetch_array($st)){
	
	


	
?>
								<td><?php echo $i++; ?></td>
                                    <td><?php echo $row['id']; ?></td>
                                    
                                    <td><?php echo $row['created']; ?></td>
                                    
                                    <td>$<?php echo $row['total']; ?></td>
									<td><?php echo $row['payment_type']; ?></td>
									<td>
                                        <button class="pd-setting"><?php echo $row['status']; ?></button>
                                    </td>
									 <td>
			<a href='product-order-details.php?prodid=<?php echo $row ['id'];?>' ><button data-toggle="tooltip" title="List" class="pd-setting-ed"><i class="fa fa-list" aria-hidden="true"></i></button> </a>
			<a href='product-order-print.php?prodid=<?php echo $row ['id'];?>'><button data-toggle="tooltip" title="Print" class="pd-setting-ed"><i class="fa fa-print" aria-hidden="true"></i></button> </a>

                                      <a  href='product-order.php?delid=<?php echo $row ['id'];?>'onclick="return confirm('Are you sure you want to delete this item?');"><button data-toggle="tooltip" title="Delete" class="pd-setting-ed"><i class="fa fa-trash-o" aria-hidden="true"></i></button>  </a>
                                        
                                    </td>
                                  
                                </tr>
	

<?php
}
?>
                                
                            </table>
                            <div class="custom-pagination">
								<nav aria-label="Page navigation">
						  <ul class="pagination">
						  <?php if($currentPage != $firstPage) { ?>
							<li class="page-item">
							  <a class="page-link" href="?page=<?php echo $firstPage ?>" tabindex="-1" aria-label="Previous">
								<span aria-hidden="true">First</span>			
							  </a>
							</li>
							<?php } ?>
							<?php if($currentPage >= 2) { ?>
								<li class="page-item"><a class="page-link" href="?page=<?php echo $previousPage ?>"><?php echo $previousPage ?></a></li>
							<?php } ?>
							<li class="page-item active"><a class="page-link" href="?page=<?php echo $currentPage ?>"><?php echo $currentPage ?></a></li>
							<?php if($currentPage != $lastPage) { ?>
								<li class="page-item"><a class="page-link" href="?page=<?php echo $nextPage ?>"><?php echo $nextPage ?></a></li>
								<li class="page-item">
								  <a class="page-link" href="?page=<?php echo $lastPage ?>" aria-label="Next">
									<span aria-hidden="true">Last</span>
								  </a>
								</li>
							<?php } ?>
						  </ul>
						</nav>
						
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php
include("footer.php");
?>