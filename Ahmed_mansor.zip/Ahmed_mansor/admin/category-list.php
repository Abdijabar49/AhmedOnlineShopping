<?php
include("header.php");
include("menu.php");
include("dbconnection.php");
if(isset($_GET["delid"]))
{
$sqldel = "DELETE FROM category where id='$_GET[delid]'";
$resdel = mysqli_query($con,$sqldel);
	if(!$resdel)
	{
		$msg= "<font color='red'>Failed to delete... Problem in sql query </font>";
	}
	else
	{
		$msg = "<font color='green'>Record deleted successfully..</font>";
	}
}
?>
   
            <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list single-page-breadcome">
                                <div class="row">
									 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <div class="breadcome-heading">
                                              
								<form action="" name="searchfrm" method="post"
								  enctype="multipart/form-data" >
								   <strong><p style= 'float:left; margin-left:1px; margin-top:6px; 
									font-size:15px;'> 
								  <input type="text" name="search_value" placeholder="  search..." style="width:200;height:39px;border-radius:10px;"  required>
								  <input class='searching-tab' style="height:39px;width:117px;font-weight:bold; "
								  type="submit" name="search" value="Search"> 
								  </p></strong>
								  </form>
										 
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Category List</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="product-status mg-tb-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-status-wrap">
                            <h4>Category List</h4>
                            <div class="add-product">
                                <a href="addcategory.php">Add Category</a>
                            </div>
                            <table>
                                <tr>
									<th>S/n</th>
                                    <th>Category</th>
                                    <th>Description</th>
									<th>Status</th>
                                    <th>Setting</th>
                                </tr>
								<?php 
								$showRecordPerPage = 10;
	if(isset($_GET['page']) && !empty($_GET['page'])){
		$currentPage = $_GET['page'];
	}else{
		$currentPage = 1;
	}
	$startFrom = ($currentPage * $showRecordPerPage) - $showRecordPerPage;
	$totalEmpSQL = "SELECT * FROM category";
	$allEmpResult = mysqli_query($con, $totalEmpSQL);
	$totalEmployee = mysqli_num_rows($allEmpResult);
	$lastPage = ceil($totalEmployee/$showRecordPerPage);
	$firstPage = 1;
	$nextPage = $currentPage + 1;
	$previousPage = $currentPage - 1;
										 $msg=null;
				   
$i=1;
	if(isset($_POST['search']))
    {
        $search = $_POST['search_value'];
        $query_search = "SELECT * FROM category WHERE name LIKE '$search%'
		OR qty LIKE '$search%' OR description LIKE '$search%' OR status LIKE '$search%'";
        $st = mysqli_query($con,$query_search);
		}
		else
		{

	$sql = "SELECT * FROM category ORDER BY id desc LIMIT $startFrom, $showRecordPerPage";   
						$st = mysqli_query($con, $sql);
	
//$st=mysqli_query($con,"select * from product order by id desc");
		}			   
if (mysqli_num_rows($st)>=1){
?>
                               
								
								<?php
					 $msg=null;
				   
$i=1;
				   


while($row=mysqli_fetch_array($st)){
	
	
	


	
?>
								<td><?php echo $i++; ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    
                                    <td><?php echo $row['description']; ?></td>
                                    
                                    
									<td>
                                        <button class="pd-setting"><?php echo $row['status']; ?></button>
                                    </td>
									 <td>
			<a href='addcategory.php?editid=<?php echo $row ['id'];?>'><button data-toggle="tooltip" title="Edit" class="pd-setting-ed"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button> </a>

                                      <a  href='category-list.php?delid=<?php echo $row ['id'];?>'onclick="return confirm('Are you sure you want to delete this item?');"><button data-toggle="tooltip" title="Trash" class="pd-setting-ed"><i class="fa fa-trash-o" aria-hidden="true"></i></button>  </a>
                                        
                                    </td>
                                  
                                </tr>
	

<?php
}
}
else{
						 echo'<br><br><b><font color="red" size="4">No Result found</font><b/><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>';

						}
?>
                                
                            </table>
                            <div class="custom-pagination">
								<nav aria-label="Page navigation">
						  <ul class="pagination">
						  <?php if($currentPage != $firstPage) { ?>
							<li class="page-item">
							  <a class="page-link" href="?page=<?php echo $firstPage ?>" tabindex="-1" aria-label="Previous">
								<span aria-hidden="true">First</span>			
							  </a>
							</li>
							<?php } ?>
							<?php if($currentPage >= 2) { ?>
								<li class="page-item"><a class="page-link" href="?page=<?php echo $previousPage ?>"><?php echo $previousPage ?></a></li>
							<?php } ?>
							<li class="page-item active"><a class="page-link" href="?page=<?php echo $currentPage ?>"><?php echo $currentPage ?></a></li>
							<?php if($currentPage != $lastPage) { ?>
								<li class="page-item"><a class="page-link" href="?page=<?php echo $nextPage ?>"><?php echo $nextPage ?></a></li>
								<li class="page-item">
								  <a class="page-link" href="?page=<?php echo $lastPage ?>" aria-label="Next">
									<span aria-hidden="true">Last</span>
								  </a>
								</li>
							<?php } ?>
						  </ul>
						</nav>
						
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php
include("footer.php");
?>