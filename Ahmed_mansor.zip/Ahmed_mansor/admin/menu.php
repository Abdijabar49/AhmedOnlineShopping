 
<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
             Ahmed Mansor Shopping
                <strong><img src="img/logo/logosn.png" alt="" /></strong>
            </div>
			       <?php 
		  if(isset($_SESSION["type"]))
		  {
		  if($_SESSION["type"]=="Administrator")
		  {
			  ?> 
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li class="active">
                     <a title="home Page" href="index.php" aria-expanded="false"><i class="fa big-icon fa-home icon-wrap" aria-hidden="true"></i> <span class="mini-click-non">Home</span></a></li>

						 <li>
                            <a class="has-arrow" href="mailbox.html" aria-expanded="false"><i class="fa big-icon fa-user-plus icon-wrap" ></i> <span class="mini-click-non">Manage Users</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Basic Form Elements" href="adduser.php"><i class="fa fa-user-plus sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Add Users</span></a></li>
                                <li><a title="Advance Form Elements" href="user-list.php"><i class="fa fa-users sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">View Users</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="mailbox.html" aria-expanded="false"><i class="fa big-icon fa-female icon-wrap"></i> <span class="mini-click-non">Manage Products</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                              
                                <li><a title="Compose Mail" href="addproduct.php"><i class="fa fa-pencil sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Add Product</span></a></li>
                                <li><a title="View Mail" href="product-list.php"><i class="fa fa-television sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">View Product</span></a></li>

							</ul>
                        </li>
                     
                       
                        <li>
                            <a class="has-arrow" href="mailbox.html" aria-expanded="false"><i class="fa big-icon fa-desktop icon-wrap"></i> <span class="mini-click-non">Manage Orders</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Notifications" href="product-order.php"><i class="fa fa-external-link-square sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Product Order</span></a></li>
                                <li><a title="Alerts" href="#"><i class="fa fa-crop sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Product Payment</span></a></li>
                            </ul>
                        </li>
                      
                       <li> <a title="home Page" href="../logout.php"  aria-expanded="false"><i class="fa big-icon fa-power-off icon-wrap" aria-hidden="true"></i> <span class="mini-click-non">Logout</span></a></li>

						
                    </ul>
                </nav>
            </div>
							 <?php 
  }
  else if($_SESSION["type"]=="User")
  {

	  ?>
	  <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li class="active">
                     <a title="home Page" href="index.php" aria-expanded="false"><i class="fa big-icon fa-home icon-wrap" aria-hidden="true"></i> <span class="mini-click-non">Home</span></a></li>

						
                        <li>
                            <a class="has-arrow" href="mailbox.html" aria-expanded="false"><i class="fa big-icon fa-female icon-wrap"></i> <span class="mini-click-non">Manage Products</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                      
                                <li><a title="Compose Mail" href="addproduct.php"><i class="fa fa-pencil sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Add Product</span></a></li>
                                <li><a title="View Mail" href="product-list.php"><i class="fa fa-television sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">View Product</span></a></li>

							</ul>
                        </li>
                     
                       
                        <li>
                            <a class="has-arrow" href="mailbox.html" aria-expanded="false"><i class="fa big-icon fa-desktop icon-wrap"></i> <span class="mini-click-non">Manage Orders</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Notifications" href="product-order.php"><i class="fa fa-external-link-square sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Product Order</span></a></li>
                                <li><a title="Alerts" href="#"><i class="fa fa-crop sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Product Payment</span></a></li>
                            </ul>
                        </li>
                        <li id="removable">
                            <a class="has-arrow" href="#" aria-expanded="false"><i class="fa big-icon fa-table icon-wrap"></i> <span class="mini-click-non">Reports</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Login" href="#"><i class="fa fa-hand-rock-o sub-icon-mg" aria-hidden="true"></i><span class="mini-sub-pro">Product</span></a></li>
                                <li><a title="Register" href="#"><i class="fa fa-plane sub-icon-mg" aria-hidden="true"></i><span class="mini-sub-pro">Product Payment</span></a></li>
                                <li><a title="Lock" href="#"><i class="fa fa-file sub-icon-mg" aria-hidden="true"></i><span class="mini-sub-pro">Product Order</span></a></li>
                            </ul>
                        </li>
                       <li> <a title="home Page" href="../logout.php"  aria-expanded="false"><i class="fa big-icon fa-power-off icon-wrap" aria-hidden="true"></i> <span class="mini-click-non">Logout</span></a></li>

						
                    </ul>
                </nav>
            </div>
					 <?php 
				  }
  }
	 ?>
        </nav>
    </div>
 <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="index.html"><img class="main-logo" src="img/logo/logo2.png"  alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-advance-area">
            <div class="header-top-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="header-top-wraper">
                                <div class="row">
                                    <div class="col-lg-1 col-md-0 col-sm-1 col-xs-12">
                                        <div class="menu-switcher-pro">
                                            <button type="button" id="sidebarCollapse" class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
													<i class="fa fa-bars"></i>
												</button>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-7 col-sm-6 col-xs-12">
                                        <div class="header-top-menu tabl-d-n">
                                            <ul class="nav navbar-nav mai-top-nav">
                                                <li class="nav-item"><a href="index.php" class="nav-link"><marquee> Welcome to Ahmed Mansor </marquee></a>
                                                </li>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                        <div class="header-right-info">
                                            <ul class="nav navbar-nav mai-top-nav header-right-menu">
                                               
                                                <li class="nav-item">
                                                    <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
															<i class="fa fa-user adminpro-user-rounded header-riht-inf" aria-hidden="true"></i>
															<span class="admin-name"><?php echo $_SESSION["fname"]. " ".$_SESSION["lname"]; ?> </span>
															<i class="fa fa-angle-down adminpro-icon adminpro-down-arrow"></i>
														</a>
                                                    <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated zoomIn">
                                                        
                                                        <li><a href="profile.php"><span class="fa fa-user author-log-ic"></span>My Profile</a>
                                                        </li>
														<li><a href="../logout.php"><span class="fa fa-lock author-log-ic"></span>Log Out</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                               
                                              
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu start -->
            <div class="mobile-menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="mobile-menu">
                                <nav id="dropdown">
								    <?php 
				  if(isset($_SESSION["type"]))
				  {
				  if($_SESSION["type"]=="Administrator")
				  {
					  ?>
                                    <ul class="mobile-menu-nav">
                                        <li><a data-toggle="collapse" data-target="#Charts" href="#">Home <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>

                                        </li>
                                        <li><a data-toggle="collapse" data-target="#demo" href="#">Manage Users <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                            <ul id="demo" class="collapse dropdown-header-top">
                                                <li><a href="adduser.php">Add User</a>
                                                </li>
                                                <li><a href="user-list.php">View Users</a>
                                                </li>
                                          </ul>
                                        </li>
                                       
                                       
                                      
                                        <li><a data-toggle="collapse" data-target="#formsmob" href="#">Manage Products <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                            <ul id="formsmob" class="collapse dropdown-header-top">
                                                <li><a href="addcategory.php">Add Category</a>
                                                </li>
                                                <li><a href="category-list.php">View Category</a>
                                                </li>
                                                <li><a href="addproduct.php">Add Product</a>
                                                </li>
                                                <li><a href="product-list.php">View Product</a>
                                                </li>
                                                
                                            </ul>
                                        </li>
                                       
                                        <li><a data-toggle="collapse" data-target="#Pagemob" href="#">Manage Order <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                            <ul id="Pagemob" class="collapse dropdown-header-top">
                                                <li><a href="product-order.php">Product Order</a>
                                                </li>
                                                <li><a href="#">Product Payment</a>
                                                </li>
                                         
                                            </ul>
                                        </li>
										 <li><a data-toggle="collapse" data-target="#Pagemob" href="#">Report <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                            <ul id="Pagemob" class="collapse dropdown-header-top">
                                                <li><a href="#">Product</a>
                                                </li>
                                                <li><a href="#">Product Payment</a>
                                                </li>
                                         
                                            </ul>
                                        </li>
										<li><a data-toggle="collapse" data-target="#Pagemob" href="#">Profile <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                            <ul id="Pagemob" class="collapse dropdown-header-top">
                                                <li><a href="#">Profile</a>
                                                </li>
                                                <li><a href="../logout">Logout</a>
                                                </li>
                                         
                                            </ul>
                                        </li>
                                    </ul>
													 <?php 
				  }
				  else if($_SESSION["type"]=="User")
				  {

					  ?>
					  <ul class="mobile-menu-nav">
                                        <li><a data-toggle="collapse" data-target="#Charts" href="#">Home <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>

                                        </li>
                                       
                                       
                                       
                                      
                                        <li><a data-toggle="collapse" data-target="#formsmob" href="#">Manage Products <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                            <ul id="formsmob" class="collapse dropdown-header-top">
                                                <li><a href="addcategory.php">Add Category</a>
                                                </li>
                                                <li><a href="category-list.php">View Category</a>
                                                </li>
                                                <li><a href="addproduct.php">Add Product</a>
                                                </li>
                                                <li><a href="product-list.php">View Product</a>
                                                </li>
                                                
                                            </ul>
                                        </li>
                                       
                                        <li><a data-toggle="collapse" data-target="#Pagemob" href="#">Manage Order <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                            <ul id="Pagemob" class="collapse dropdown-header-top">
                                                <li><a href="product-order.php">Product Order</a>
                                                </li>
                                                <li><a href="#">Product Payment</a>
                                                </li>
                                         
                                            </ul>
                                        </li>
										 <li><a data-toggle="collapse" data-target="#Pagemob" href="#">Report <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                            <ul id="Pagemob" class="collapse dropdown-header-top">
                                                <li><a href="#">Product</a>
                                                </li>
                                                <li><a href="#">Product Payment</a>
                                                </li>
                                         
                                            </ul>
                                        </li>
										<li><a data-toggle="collapse" data-target="#Pagemob" href="#">Profile <span class="admin-project-icon adminpro-icon adminpro-down-arrow"></span></a>
                                            <ul id="Pagemob" class="collapse dropdown-header-top">
                                                <li><a href="#">Profile</a>
                                                </li>
                                                <li><a href="../logout">Logout</a>
                                                </li>
                                         
                                            </ul>
                                        </li>
                                    </ul>
					  
					  
					  		 <?php 
							  }
			  }
				 ?>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu end -->