<?php
include("header.php");
include("menu.php");
include("dbconnection.php");
?>
            <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list single-page-breadcome">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Add User </span>
                                            </li>
                                        </ul>
                                    </div>
									
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Single pro tab start-->
        <div class="single-product-tab-area mg-tb-15">
            <!-- Single pro tab review Start-->
            <div class="single-pro-review-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="review-tab-pro-inner">
                                <ul id="myTab3" class="tab-review-design">
                                    <li class="active"><a href="#description"><i class="fa fa-pencil" aria-hidden="true"></i><?php if(isset($_GET['editid'])) { ?>User Edit<?php } else { ?> Add Users<?php } ?></a>
</li>
                                    
                                </ul>
								 <div class="add-product">
                                <a href="user-list.php">View User</a>
								</div>
	   <?php 
	$msg=null;
$dt= date("Y-m-d"); 
if(isset($_POST["insert"]))
{ 
//image1 
				if($_FILES["image1"]['size'] == 0)
				{
				$img1 = $_POST['oldimage1'];
				}
				else
				{
				$img1 = rand(). $_FILES["image1"]["name"];
				move_uploaded_file($_FILES["image1"]["tmp_name"],"upload/".$img1);
				}
				
	if(isset($_GET["editid"]))
		{
			$sqlupd = "UPDATE users SET firstName='$_POST[fname]',lastName='$_POST[lname]',contact='$_POST[contact]',jobTitle='$_POST[jobTitle]',gender='$_POST[gender]',userType='$_POST[userType]',email='$_POST[email]',password='$_POST[password]',photo='$img1',status='$_POST[status]' WHERE userID='$_GET[editid]'";
	$qresult = mysqli_query($con,$sqlupd);
	$ctins =  mysqli_affected_rows($con);
			if(!$qresult)
	{
		$msg = "<br><font color='green' size='4'>Failed to update record </font>";
	}
	else
	{
		$msg = "<font color='green' size='4'><br>Record updated successfully...</font>";

	}
	}
		else
		{
 $sql1 = "select username from users where username = '$_POST[username]'";
    $result1 = mysqli_query($con,$sql1) or die ("Couldn't execute query.");										  
    
	$num1=mysqli_num_rows($result1);
	if($num1 == 1)
	{
		
		$msg = "<font color='red'> Sorry ! username allready exists , Please Try another one  </font><font color='darkBlue'>".$_POST["username"]."</font>";
	}
	else
	{   
$usersSql=mysqli_query($con,"insert into users(firstName,lastName,contact,email,jobTitle,gender,username,password,userType,status,registerDate,photo) values('$_POST[fname]','$_POST[lname]','$_POST[contact]','$_POST[email]','$_POST[jobTitle]','$_POST[gender]','$_POST[username]','$_POST[password]','$_POST[userType]','$_POST[status]','$dt','$img1')");
if(!$usersSql)
	{
		$msg ="<font color='red' size='4'>Failed to insert... Problem in sql query</font>";
	}
	else
	{
		$msg = "<font color='green' size='4'><br>Record Added successfully...</font>";

	}
	}
	
		}
}
$ctins=null;
if(isset($_GET["editid"]))
{
$sqlst = "SELECT * FROM users WHERE userid='$_GET[editid]'";
$sqquery = mysqli_query($con,$sqlst);
$row = mysqli_fetch_array($sqquery);
}
 
?>
<script type="text/javascript">
function validate() 
{
	if(document.showroom.password.value != document.showroom.conpass.value)
	{
		alert("Password and confirm password not matching.");
		document.showroom.conpass.focus();
		return false;
	}
 else if(document.showroom.gender.value== "Select Gender")
	{
		alert("Please select Gender");
		document.showroom.email.focus();
		return false;
	}
else if(document.showroom.userType.value== "Select Type")
	{
		alert("Please select Type");
		document.showroom.conpass.focus();
		return false;
	}
else if(document.showroom.status.value== "Select Status")
	{
		alert("Please select Status");
		document.showroom.conpass.focus();
		return false;
	}
}
</script>

									 <center> <?php echo $msg; ?> </center> <br>
								<form  class="form-horizontal" name="showroom" method="post" action="" enctype="multipart/form-data" onsubmit="return validate()">
                                <div id="myTabContent" class="tab-content custom-product-edit">
                                    <div class="product-tab-list tab-pane fade active in" id="description">
                                        <div class="row">
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                <div class="review-content-section">
                                                    
													

                                                    <div class="input-group mg-b-pro-edt">
                                                        <span class="input-group-addon"><i class="fa fa-user" aria-hidden="true"></i></span>
                                                        <input type="text" class="form-control" placeholder="First Name" id="fname" name="fname" value="<?php if(isset($_GET["editid"])){echo $row['firstName']; } ?>">
														<script type="text/javascript">
															var f1 = new LiveValidation('fname');
															f1.add(Validate.Presence,{failureMessage: " Please enter Firstname"});
														   f1.add(Validate.Format,{pattern: /^[a-zA-Z\s]+$/i ,failureMessage:" It allows only characters"});
															f1.add(Validate.Format,{pattern: /^[a-zA-Z][a-zA-Z\s]{0,}$/,failureMessage: 
																   " Invalid Firstname"});
														 </script>
                                                    </div>
													<div class="input-group mg-b-pro-edt">
                                                        <span class="input-group-addon"><i class="fa fa-user" aria-hidden="true"></i></span>
                                                        <input type="text" class="form-control" value="<?php if(isset($_GET["editid"])){echo $row['lastName']; } ?>" placeholder="Last Name" id="lname" name="lname">
                                                      <script type="text/javascript">
														var f1 = new LiveValidation('lname');
														f1.add(Validate.Presence,{failureMessage: " Please enter Lastname"});
													   f1.add(Validate.Format,{pattern: /^[a-zA-Z\s]+$/i ,failureMessage:" It allows only characters"});
														f1.add(Validate.Format,{pattern: /^[a-zA-Z][a-zA-Z\s]{0,}$/,failureMessage: 
															   " Invalid Lastname"});
													 </script>
													</div>
													
                                                    <div class="input-group mg-b-pro-edt">
                                                        <span class="input-group-addon"><i class="fa fa-paper-plane sub-icon-mg" aria-hidden="true"></i></span>
                                                        <input type="text" class="form-control" placeholder="Contact" id="contact" name="contact" value="<?php if(isset($_GET["editid"])){echo $row['contact']; } ?>">
                                                    								 <script type="text/javascript">
																							var f1 = new LiveValidation('contact');
																						   f1.add(Validate.Presence,{failureMessage: " Please enter contact"});
																						   f1.add(Validate.Format,{pattern: /^[0-9]+$/ ,failureMessage: " It allows only numbers"});
																						   f1.add( Validate.Length, { maximum: 10 } );
																					  </script>
													</div>
                                                    
                                                    <div class="input-group mg-b-pro-edt">
                                                        <span class="input-group-addon"><i class="fa fa-female sub-icon-mg" aria-hidden="true"></i></span>
                                                        <input type="text" class="form-control" placeholder="job Title" id="jobTitle" name="jobTitle" value="<?php if(isset($_GET["editid"])){echo $row['jobTitle']; } ?>">
																<script type="text/javascript">
																	var f1 = new LiveValidation('jobTitle');
																	f1.add(Validate.Presence,{failureMessage: " Please enter jobTitle"});
																  
																 </script>
													</div>
													
													<div class="input-group mg-b-pro-edt">
                                                        <span class="input-group-addon"><i class="fa big-icon fa-envelope icon-wrap" aria-hidden="true"></i></span>
                                                        <input type="text" class="form-control" placeholder="Email" id="email" name="email" value="<?php if(isset($_GET["editid"])){echo $row['email']; } ?>" >
																<script type="text/javascript">
																		var f1 = new LiveValidation('email');
																		f1.add(Validate.Presence,{failureMessage: " Please enter Email"});
																		f1.add( Validate.Email );
																</script>
													</div>
													
													
													 <select name="gender" class="form-control" >
														<?php
														$arr = array("Select Gender","Male","Female");
														foreach($arr as $val)
														{
															if($val == $row["gender"])
															{
															echo "<option value='$val' selected>$val</option>";
															}
															else
															{
															echo "<option value='$val'>$val</option>";
															}
														}
														?>
														</select>
														
                                                </div>
                                            </div>
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                <div class="review-content-section">
                                                    
                                                    
                                                   
                                                    
													<div class="input-group mg-b-pro-edt">
                                                        <span class="input-group-addon"><i class="fa fa-pencil sub-icon-mg" aria-hidden="true"></i></span>
                                                        <input type="text" class="form-control" value="<?php if(isset($_GET["editid"])){echo $row['username']; } ?>" placeholder="Username" id="username" name="username">
																		<script type="text/javascript">
																			var f1 = new LiveValidation('username');
																			f1.add(Validate.Presence,{failureMessage: " Please enter username"});
																		  
																		 </script>
													</div>
													<div class="input-group mg-b-pro-edt">
                                                        <span class="input-group-addon"><i class="fa fa-hourglass sub-icon-mg" aria-hidden="true"></i></span>
                                                        <input type="password" class="form-control" value="<?php if(isset($_GET["editid"])){echo $row['password']; } ?>" placeholder="Password" id="password" name="password">
                                                      <script type="text/javascript">
															var f1 = new LiveValidation('password');
															f1.add(Validate.Presence,{failureMessage: " Please enter password"});
														  
														 </script>
													</div>
													<div class="input-group mg-b-pro-edt">
                                                        <span class="input-group-addon"><i class="fa fa-hourglass sub-icon-mg" aria-hidden="true"></i></span>
                                                        <input type="password" class="form-control" value="<?php if(isset($_GET["editid"])){echo $row['password']; } ?>" placeholder="Confirm Password" id="conpass" name="conpass">
															<script type="text/javascript">
																var f1 = new LiveValidation('conpass');
																f1.add(Validate.Presence,{failureMessage: " Please enter Re-password"});
															  
															 </script>
													</div>
													<select name="userType" class="form-control">
														<?php
														$arr = array("Select Type","Administrator","User");
														foreach($arr as $val)
														{
															if($val == $row["userType"])
															{
															echo "<option value='$val' selected>$val</option>";
															}
															else
															{
															echo "<option value='$val'>$val</option>";
															}
														}
														?>
														</select>
														<br>
													<div class="input-group mg-b-pro-edt">
                                                        
														 <span class="input-group-addon"><label>Photo</label></span> 
                                                         <input name="image1" type="file" size="20" value="<?php echo $row["photo"]; ?>" style="width:250px; height:35px;">
														<input type="hidden" name="oldimage1" value="<?php echo $row["photo"]; ?>" class="form-control"/>
															<?php   
															if(isset($_GET["editid"]))     
															{
																if($row["photo"] == "")
																{
																echo "<img src='images/noimage.jpg' width='70' height='70'>";		
																}
																else
																{
																echo "<img src='upload/$row[photo]' width='70' height='70'>";
																}
															}
															?>
                                                    </div>
										
													
													<select name="status" class="form-control" class="form-control pro-edt-select form-control-primary" >
														<?php
														$arr = array("Select Status","Active","Disabled","Paused");
														foreach($arr as $val)
														{
															if($val == $row["status"])
															{
															echo "<option value='$val' selected>$val</option>";
															}
															else
															{
															echo "<option value='$val'>$val</option>";
															}
														}
														?>
														</select>
                                                   
														
														
                                                </div>
                                            </div>
                                        </div>
										<br>
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="text-center mg-b-pro-edt custom-pro-edt-ds">
												 <?php if(isset($_GET['editid'])) { ?> <button type="submit" class="btn btn-primary waves-effect waves-light m-r-10" name="insert">Update Record</button><?php } else { ?> <button type="submit" class="btn btn-primary waves-effect waves-light m-r-10" name="insert">Add Record</button><?php } ?>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
									</form>
                                    <div class="product-tab-list tab-pane fade" id="reviews">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="review-content-section">
                                                    <div class="row">
                                                        <div class="col-lg-4">
                                                            <div class="pro-edt-img">
                                                                <img src="img/new-product/5-small.jpg" alt="" />
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-8">
                                                            <div class="row">
                                                                <div class="col-lg-12">
                                                                    <div class="product-edt-pix-wrap">
                                                                        <div class="input-group">
                                                                            <span class="input-group-addon">TT</span>
                                                                            <input type="text" class="form-control" placeholder="Label Name">
                                                                        </div>
                                                                        <div class="row">
                                                                            <div class="col-lg-6">
                                                                                <div class="form-radio">
                                                                                    <form>
                                                                                        <div class="radio radiofill">
                                                                                            <label>
																									<input type="radio" name="radio"><i class="helper"></i>Largest Image
																								</label>
                                                                                        </div>
                                                                                        <div class="radio radiofill">
                                                                                            <label>
																									<input type="radio" name="radio"><i class="helper"></i>Medium Image
																								</label>
                                                                                        </div>
                                                                                        <div class="radio radiofill">
                                                                                            <label>
																									<input type="radio" name="radio"><i class="helper"></i>Small Image
																								</label>
                                                                                        </div>
                                                                                    </form>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-lg-6">
                                                                                <div class="product-edt-remove">
                                                                                    <button type="button" class="btn btn-danger waves-effect waves-light">Remove
																							<i class="fa fa-times" aria-hidden="true"></i>
																						</button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-lg-4">
                                                            <div class="pro-edt-img">
                                                                <img src="img/new-product/6-small.jpg" alt="" />
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-8">
                                                            <div class="row">
                                                                <div class="col-lg-12">
                                                                    <div class="product-edt-pix-wrap">
                                                                        <div class="input-group">
                                                                            <span class="input-group-addon">TT</span>
                                                                            <input type="text" class="form-control" placeholder="Label Name">
                                                                        </div>
                                                                        <div class="row">
                                                                            <div class="col-lg-6">
                                                                                <div class="form-radio">
                                                                                    <form>
                                                                                        <div class="radio radiofill">
                                                                                            <label>
																									<input type="radio" name="radio"><i class="helper"></i>Largest Image
																								</label>
                                                                                        </div>
                                                                                        <div class="radio radiofill">
                                                                                            <label>
																									<input type="radio" name="radio"><i class="helper"></i>Medium Image
																								</label>
                                                                                        </div>
                                                                                        <div class="radio radiofill">
                                                                                            <label>
																									<input type="radio" name="radio"><i class="helper"></i>Small Image
																								</label>
                                                                                        </div>
                                                                                    </form>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-lg-6">
                                                                                <div class="product-edt-remove">
                                                                                    <button type="button" class="btn btn-danger waves-effect waves-light">Remove
																							<i class="fa fa-times" aria-hidden="true"></i>
																						</button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-lg-4">
                                                            <div class="pro-edt-img">
                                                                <img src="img/new-product/7-small.jpg" alt="" />
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-8">
                                                            <div class="row">
                                                                <div class="col-lg-12">
                                                                    <div class="product-edt-pix-wrap">
                                                                        <div class="input-group">
                                                                            <span class="input-group-addon">TT</span>
                                                                            <input type="text" class="form-control" placeholder="Label Name">
                                                                        </div>
                                                                        <div class="row">
                                                                            <div class="col-lg-6">
                                                                                <div class="form-radio">
                                                                                    <form>
                                                                                        <div class="radio radiofill">
                                                                                            <label>
																									<input type="radio" name="radio"><i class="helper"></i>Largest Image
																								</label>
                                                                                        </div>
                                                                                        <div class="radio radiofill">
                                                                                            <label>
																									<input type="radio" name="radio"><i class="helper"></i>Medium Image
																								</label>
                                                                                        </div>
                                                                                        <div class="radio radiofill">
                                                                                            <label>
																									<input type="radio" name="radio"><i class="helper"></i>Small Image
																								</label>
                                                                                        </div>
                                                                                    </form>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-lg-6">
                                                                                <div class="product-edt-remove">
                                                                                    <button type="button" class="btn btn-danger waves-effect waves-light">Remove
																							<i class="fa fa-times" aria-hidden="true"></i>
																						</button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="product-tab-list tab-pane fade" id="INFORMATION">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="review-content-section">
                                                    <div class="card-block">
                                                        <div class="text-muted f-w-400">
                                                            <p>No reviews yet.</p>
                                                        </div>
                                                        <div class="m-t-10">
                                                            <div class="txt-primary f-18 f-w-600">
                                                                <p>Your Rating</p>
                                                            </div>
                                                            <div class="stars stars-example-css detail-stars">
                                                                <div class="review-rating">
                                                                    <fieldset class="rating">
                                                                        <input type="radio" id="star5" name="rating" value="5">
                                                                        <label class="full" for="star5"></label>
                                                                        <input type="radio" id="star4half" name="rating" value="4 and a half">
                                                                        <label class="half" for="star4half"></label>
                                                                        <input type="radio" id="star4" name="rating" value="4">
                                                                        <label class="full" for="star4"></label>
                                                                        <input type="radio" id="star3half" name="rating" value="3 and a half">
                                                                        <label class="half" for="star3half"></label>
                                                                        <input type="radio" id="star3" name="rating" value="3">
                                                                        <label class="full" for="star3"></label>
                                                                        <input type="radio" id="star2half" name="rating" value="2 and a half">
                                                                        <label class="half" for="star2half"></label>
                                                                        <input type="radio" id="star2" name="rating" value="2">
                                                                        <label class="full" for="star2"></label>
                                                                        <input type="radio" id="star1half" name="rating" value="1 and a half">
                                                                        <label class="half" for="star1half"></label>
                                                                        <input type="radio" id="star1" name="rating" value="1">
                                                                        <label class="full" for="star1"></label>
                                                                        <input type="radio" id="starhalf" name="rating" value="half">
                                                                        <label class="half" for="starhalf"></label>
                                                                    </fieldset>
                                                                </div>
                                                                <div class="clear"></div>
                                                            </div>
                                                        </div>
                                                        <div class="input-group mg-b-15 mg-t-15">
                                                            <span class="input-group-addon"><i class="fa fa-user" aria-hidden="true"></i></span>
                                                            <input type="text" class="form-control" placeholder="User Name">
                                                        </div>
                                                        <div class="input-group mg-b-15">
                                                            <span class="input-group-addon"><i class="fa fa-user" aria-hidden="true"></i></span>
                                                            <input type="text" class="form-control" placeholder="Last Name">
                                                        </div>
                                                        <div class="input-group mg-b-15">
                                                            <span class="input-group-addon"><i class="fa fa-envelope-o" aria-hidden="true"></i></span>
                                                            <input type="text" class="form-control" placeholder="Email">
                                                        </div>
                                                        <div class="form-group review-pro-edt">
                                                            <button type="submit" class="btn btn-primary waves-effect waves-light">Submit
																</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
   <?php
include("footer.php");
?>