<div class="col-lg-3">

					<!-- Shop Sidebar -->
					<div class="shop_sidebar">
					<div>
                    <a href="#" class="list-group-item active">Categories
                    </a>
                    <ul class="list-group">
				
			<li class="list-group-item">
			<i class="icon fa fa-desktop"></i>
                
				 
                        </li>
             
     
                        
                    </ul>
                </div>
				<br>
				
						
						
					</div>

				</div>